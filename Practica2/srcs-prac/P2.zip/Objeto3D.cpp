#include "Objeto3D.hpp"

inline std::string Objeto3D::nombre(){
    return nombre_obj;
}