// *********************************************************************
// **
// ** Informática Gráfica, curso 2015-16
// ** Práctica 2  (Funcion de rotacion)
// **
// *********************************************************************

#ifndef IG_PRACTICA2_HPP
#define IG_PRACTICA2_HPP

void P2_Inicializar( int argc, char *argv[] ) ;
bool P2_FGE_PulsarTeclaNormal(  unsigned char tecla ) ;
void P2_DibujarObjetos( unsigned modo ) ;

#endif
