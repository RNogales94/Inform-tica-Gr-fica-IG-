#ifndef CILINDRO_HPP
#define CILINDRO_HPP

#include "MallaInd.hpp"
// .....
#include "tuplasg.hpp" // Tupla3f

class Cilindro : public MallaInd
{
	
public:
	Cilindro(int num_caras) ; // crea las tablas del cilindro, y le da nombre.

} ;

#endif
