#include "NodoGrafoEscena.hpp"
#include "Objeto3D.hpp"
#include "MallaInd.hpp"
#include "Cilindro.hpp"
#include <vector>
#include "tuplasg.hpp" // Tupla3f
#include "matrices-tr.hpp"



class ColumnaIzquierda : public NodoGrafoEscena{
	public:
		ColumnaIzquierda(); //constructor
};

class ColumnaDerecha : public NodoGrafoEscena{
	public:
		ColumnaDerecha(); //constructor
};

class Cabina : public NodoGrafoEscena{
	public:
		Cabina(); //constructor
};

class Base : public NodoGrafoEscena{
	public:
		Base(); //constructor
};

class Atraccion : public NodoGrafoEscena{
	protected:
		float h, alpha;
	public:
		Atraccion(float h_inicial, float alpha_inicial);
		void fijarH(float h_nuevo);
		void fijarAlpha(float alpha_nuevo);
};
