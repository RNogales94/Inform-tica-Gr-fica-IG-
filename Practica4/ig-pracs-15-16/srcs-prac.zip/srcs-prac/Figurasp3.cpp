#include "Figurasp3.hpp"


ColumnaIzquierda::ColumnaIzquierda(){
	agregar(MAT_Rotacion(45, 0, 1, 0));
	agregar(MAT_Escalado(1, 3, 1));
	agregar(new Cilindro(5));
}

ColumnaDerecha::ColumnaDerecha(){
	agregar(MAT_Escalado(1, 3, 1));
	agregar(MAT_Traslacion(6.0, 0.0, 0.0));
	agregar(MAT_Rotacion(45, 0, 1, 0));
	agregar(new Cilindro(5));
}

Cabina::Cabina(){
	agregar(MAT_Escalado(1, 5, 1));
	agregar(MAT_Rotacion(45, 1, 0, 0));
	agregar(MAT_Rotacion(90, 1, 0, 0));
	//agregar(MAT_Traslacion());
	agregar(new Cilindro(5));
}

Base::Base(){
}


Atraccion::Atraccion(float h_inicial, float alpha_inicial){
	
}
void Atraccion::fijarAlpha(float alpha_nuevo){
	//guardar nuevo valor de "alpha"
	alpha = alpha_nuevo;
	
	//insertar nueva matriz en la primera entrada del array
	*(entradas[0].matriz) = MAT_Rotacion(alpha_nuevo, 0, 0, 1);
}

void Atraccion::fijarH(float h_nuevo){
	//guardar nuevo valor (opcional)
	h = h_nuevo;
	
	//cambiar matriz en el nodo hijo (segunda entrada)
	//CasaEscY * hijo = (CasaEscY *)
}
