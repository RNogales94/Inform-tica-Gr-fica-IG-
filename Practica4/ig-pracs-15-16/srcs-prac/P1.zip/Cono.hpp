#include "MallaInd.hpp"
// .....
#include "tuplasg.hpp" // Tupla3f

class Cono : public MallaInd
{
	
public:
	Cono(int num_caras) ; // crea las tablas del cono, y le da nombre.

} ;
