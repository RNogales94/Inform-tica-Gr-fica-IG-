#include "Objeto3D.hpp"

//Función que devuelve el nombre del objeto
std::string Objeto3D::nombre(){
	return nombre_obj;	
}
