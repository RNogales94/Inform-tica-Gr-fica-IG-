#include "MallaInd.hpp"

void MallaInd::visualizar( unsigned modo_vis ){
	glEnableClientState(GL_VERTEX_ARRAY); //habilitar array de vértices
	glVertexPointer(3, GL_FLOAT, 0, &vertices[0]); //establecer dirección y estructura //también podría poner &vertices.front
	
	//visualizar recorriendo los vértices en el orden de los índices:
	/*for (int i=0; i<caras.size(); i++){
		glPolygonMode( GL_FRONT_AND_BACK, GL_POINT );
		glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, &caras[i]);
	}*/

	//glDrawElements(modo_vis, caras.size()*3, GL_UNSIGNED_INT, &caras[0]);
	
	
	//Como glPolygonMode solo tiene 3 modos: GL_POINT, GL_LINE y GL_FILL, el modo ajedrez lo tenemos que crear nosotros
	
	//También se podría hacer con glDrawElements y sus 3 modos: GL_POINTS, GL_LINE_LOOP Y GL_POLYGON, creando también manualmente el modo ajedrez
	
	glPointSize(8.0);
	
	if (modo_vis == 0){
		for (int i=0; i<caras.size(); i++){
			//glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
			//glDrawElements(GL_POINTS, 3, GL_UNSIGNED_INT, &caras[i]);
			glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
			glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, &caras[i]);
		}
	}
			
	else if (modo_vis == 1){
		for (int i=0; i<caras.size(); i++){
			//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			//glDrawElements(GL_LINE_LOOP, 3, GL_UNSIGNED_INT, &caras[i]);
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, &caras[i]);
		}
	}
			
	else if (modo_vis == 2){
		for (int i=0; i<caras.size(); i++){
			//glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			//glDrawElements(GL_POLYGON, 3, GL_UNSIGNED_INT, &caras[i]);
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, &caras[i]);
		}
	}
		
	else if (modo_vis == 3){
		for (int i=0; i<caras.size(); i++){
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			if ((i%2)==0){
				glColor3f(0.0, 0.0, 0.0); //negro
			}
			else{
				glColor3f(1.0, 1.0, 0.0); //verde
			}
			//glDrawElements(GL_POLYGON, 3, GL_UNSIGNED_INT, &caras[i]);
			glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, &caras[i]);
		}
	}
	
	glDisableClientState(GL_VERTEX_ARRAY); //deshabilitar array
}
