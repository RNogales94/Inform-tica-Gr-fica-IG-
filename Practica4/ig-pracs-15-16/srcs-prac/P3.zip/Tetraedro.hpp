#include "MallaInd.hpp"
// .....
#include "tuplasg.hpp" // Tupla3f

class Tetraedro : public MallaInd
{
	
public:
	Tetraedro() ; // crea las tablas del tetraedro, y le da nombre.

} ;
