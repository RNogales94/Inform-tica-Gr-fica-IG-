// *********************************************************************
// **
// ** Informática Gráfica, curso 2015-16
// ** Práctica 2  (declaraciones públicas)
// **
// *********************************************************************

#ifndef IG_ROTACION_HPP
#define IG_ROTACION_HPP

Tupla3f rotacion(Tupla3f &v, double angulo) ;

#endif
