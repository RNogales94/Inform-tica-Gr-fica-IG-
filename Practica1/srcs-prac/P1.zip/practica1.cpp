// *********************************************************************
// **
// ** Informática Gráfica, curso 2015-16
// ** Práctica 1  (implementación)
// **
// *********************************************************************

#include "aux.hpp"
#include "tuplasg.hpp"   // Tupla3f 
#include "practica1.hpp"
#include "MallaInd.hpp"
#include "Objeto3D.hpp"

unsigned objeto_activo = 0 ; // objeto activo: cubo (0), tetraedro (1), otros....

// ---------------------------------------------------------------------
// declaraciones de clases para organizacion de datos....



Tupla3f rotacion(Tupla3f &v, double angulo){
    angulo = angulo*2*M_PI/360.0;
    Tupla3f *t = new Tupla3f( v(X)*cos(angulo) - v(Z)*sin(angulo), v(Y), v(X)*sin(angulo) + v(Z)*cos(angulo) );
    return *t;
}



class Triangulo : public MallaInd{
public:
    Triangulo(){
        nombre_obj = "Triangulo";
        float punto1[3] = {1.0, 0.5, 0.0};
        float punto2[3] = {1.0, -0.5, 0.0};
        float punto3[3] = {0.5, 0.0, 0.5};
        Tupla3f p1(punto1);
        Tupla3f p2(punto2);
        Tupla3f p3(punto3);
        tabla_vertices.push_back(p1);
        tabla_vertices.push_back(p2);
        tabla_vertices.push_back(p3);
        Tupla3i i1( 0,1,2 ), i2(1,2,0), i3(0,0,0);
        tabla_indices.push_back(i1);
        tabla_indices.push_back(i2);
        tabla_indices.push_back(i3);
        
    }
};

class Cubo : public MallaInd{
public:
    Cubo(){
        nombre_obj = "Cubo";
        //Vertices de la base
        Tupla3f p0(-0.7, -0.7, -0.7), p1(-0.7, -0.7, 0.7), p2(0.7, -0.7, 0.7) , p3(0.7, -0.7, -0.7);
        
        //Vertices de la tapa
        Tupla3f p4(-0.7, 0.7, -0.7), p5(-0.7, 0.7, 0.7), p6(0.7, 0.7, 0.7), p7(0.7, 0.7, -0.7);

        tabla_vertices.push_back(p0);
        tabla_vertices.push_back(p1);
        tabla_vertices.push_back(p2);
        tabla_vertices.push_back(p3);
        tabla_vertices.push_back(p4);
        tabla_vertices.push_back(p5);
        tabla_vertices.push_back(p6);
        tabla_vertices.push_back(p7);
        
        //Ahora creamos las caras uniendo los vertices:
        
        //Base
        Tupla3i c0( 0,1,2 ), c1(0,3,2);
        tabla_indices.push_back(c0);
        tabla_indices.push_back(c1);
        
        //Cara frontal
        Tupla3i c4( 1,6,5 ), c5( 1,2,6 );
        tabla_indices.push_back(c4);
        tabla_indices.push_back(c5);
        
        //Cara Izda
        Tupla3i c10( 4,5,1 ), c11( 4,0,1 );
        tabla_indices.push_back(c10);
        tabla_indices.push_back(c11);
        
        //Cara trasera
        Tupla3i c8( 4,7,0 ), c9( 0,3,7 );
        tabla_indices.push_back(c8);
        tabla_indices.push_back(c9);
        
        //Cara Derecha
        Tupla3i c6( 7,6,2 ), c7( 3,2,7 );
        tabla_indices.push_back(c6);
        tabla_indices.push_back(c7);
        
        
        //Tapa
        Tupla3i c2(4,5,6), c3(7,4,6);
        tabla_indices.push_back(c2);
        tabla_indices.push_back(c3);

    }
    
};

class Tetraedro : public MallaInd{
public:
    Tetraedro(){
        nombre_obj = "Tetraedro";
        float punto1[3] = {1.0, 0.0, 0.0};
        Tupla3f p1(punto1);
        Tupla3f p2, p3, p4(0.0, 1.0, 0.0);
        p2 = rotacion(p1, 120);
        p3 = rotacion(p1, -120);
        tabla_vertices.push_back(p1);
        tabla_vertices.push_back(p2);
        tabla_vertices.push_back(p3);
        tabla_vertices.push_back(p4);
        
        Tupla3i i1( 1,2,0 ), i2(1,2,3), i3(2,3,0), i4(1,3,0);
        tabla_indices.push_back(i1);
        tabla_indices.push_back(i2);
        tabla_indices.push_back(i3);
        tabla_indices.push_back(i4);
    }
};

/*
 class Cilindro : public MallaInd{
 public:
 Cilindro(int n){
 nombre_obj = "Cilindro";
 
 vector<Tupla3f> base;
 vector<Tupla3f> tapa;
 
 float angulo = 2*M_PI/n;
 Tupla3f *t1;
 t1 = new Tupla3f(1.0, 0, 0);
 Tupla3f *t2;
 t2 = new Tupla3f(1.0, 1.0, 0);
 
 base.push_back(*t1);
 tabla_vertices.push_back(base[0]);
 
 for (int i=0; i<n; i++) {
 t1 = new Tupla3f(rotacion(base[i],angulo));
 base.push_back(*t1);
 tabla_vertices.push_back(base[i+1]);
 std::cout << *t1 << std::endl;
 }
 tapa.push_back(*t2);
 tabla_vertices.push_back(tapa[n]);
 for (int i=0; i<n; i++) {
 t1 = new Tupla3f(rotacion(tapa[i],angulo));
 tapa.push_back(*t1);
 tabla_vertices.push_back(tapa[i+1]);
 
 }
 Tupla3i c0( 0,1,2 ), c1(0,3,2);
 tabla_indices.push_back(c0);
 tabla_indices.push_back(c1);
 }
 
 };
 */


// declaraciones de estructuras de datos....
Triangulo* tri;
Tetraedro* tetraedro;
Cubo* cubo;
//Cilindro* cilindro;



// ---------------------------------------------------------------------
// Función para implementar en la práctica 1 para inicialización.
// Se llama una vez al inicio, cuando ya se ha creado la ventana e 
// incializado OpenGL. 

void P1_Inicializar( int argc, char *argv[] )
{
    tri = new Triangulo;
    tetraedro = new Tetraedro;
    cubo = new Cubo;
    //cilindro = new Cilindro(10);
   
}

// ---------------------------------------------------------------------
// Función invocada al pulsar una tecla con la práctica 1 activa:
// (si la tecla no se procesa en el 'main').
//
//  - devuelve 'true' si la tecla se usa en esta práctica para cambiar 
//    entre el cubo, el tetraedro u otros objetos (cambia el valor de
//    'objeto_activo').
//  - devuelve 'false' si la tecla no se usa en esta práctica (no ha
//    cambiado nada)

bool P1_FGE_PulsarTeclaNormal( unsigned char tecla ) 
{
    if (tecla=='f' || tecla=='F') {
        if(objeto_activo==0)
            objeto_activo=1;
        
        else if (objeto_activo==1)
            objeto_activo=0;
        return true;
    }
    else
        return false;
}


// ---------------------------------------------------------------------
// Función a implementar en la práctica 1  para dibujar los objetos
// modo: 0 - puntos, 1 - alambre, 2 - sólido, 3 - sólido ajedrez , >=4 otros....

void P1_DibujarObjetos( unsigned modo ) 
{
    // objeto activo: cubo (0), tetraedro (1), otros....
    if (objeto_activo==0) {
        cubo->visualizar(modo);
    }
    if (objeto_activo==1) {
        tetraedro->visualizar(modo);
    }
    /*
    if (objeto_activo==2) {
        tri->visualizar(5);
    }
     */

}
