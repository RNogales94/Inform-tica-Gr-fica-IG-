// *********************************************************************
// **
// ** Informática Gráfica, curso 2015-16
// ** Práctica 3  (Funcion de rotacion)
// **
// *********************************************************************

#ifndef IG_PRACTICA3_HPP
#define IG_PRACTICA3_HPP

void P3_Inicializar( int argc, char *argv[] ) ;
bool P3_FGE_PulsarTeclaNormal(  unsigned char tecla ) ;
void P3_DibujarObjetos( unsigned modo ) ;

#endif
